#!/usr/bin/env bash
# Run farm di VPS Ubuntu (headless virtual display). Usage:
#   chmod +x run-server.sh && ./run-server.sh
set -e
cd "$(dirname "$0")"
export TZ=Asia/Jakarta
exec node coreweave-bot.mjs --headless virtual --max-attempts 3 "$@"
