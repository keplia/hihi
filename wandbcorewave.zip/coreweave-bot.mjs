#!/usr/bin/env node
// ============================================================================
// CoreWeave x Weights&Biases ACCOUNT FARM
// ----------------------------------------------------------------------------
// Flow (per akun gt.txt):
//   id.coreweave.com/login -> tab "Sign up" -> "Continue with GitHub"
//   -> GitHub login (username + password + TOTP) -> skip 2FA settings
//   -> GitHub OAuth "Authorize Weights & Biases" (wandb.auth0.com callback)
//   -> W&B "Sign up for an account" (Full name + Org + ToS)
//   -> "Create your organization" -> "What are you working on?" (Train and fine-tune models)
//   -> forge.coreweave.com/account-settings -> Billing -> Inference Activate
//      (card dari cvc.txt, postal 16024, country Indonesia) -> API Keys -> New key
//   -> simpan key ke api.txt
//
// gt.txt      : username-SECRET2FA  (password semua akun: Kiting@220219)
// cvc.txt     : number|MM|YY|CVC
// proxy.txt   : host:port:user:pass  (ipdeep sticky session, rotate per akun)
// used.txt    : state akun gt (dibuat otomatis)
// proxy-used.txt : pointer proxy terpakai (reset ke awal kalau habis)
// api.txt     : hasil API key
// ============================================================================
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";
import { Camoufox } from "camoufox-js";
import { loadProxies, toPlaywrightProxy, parseProxyLine } from "./lib/proxy.mjs";
import { freshTotp, totp, secondsLeft, normalizeSecret } from "./lib/totp.mjs";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// ---------------- args ----------------
const argv = process.argv.slice(2);
const has = (f) => argv.includes(f);
const val = (f, def) => {
  const i = argv.indexOf(f);
  return i !== -1 && argv[i + 1] && !argv[i + 1].startsWith("--") ? argv[i + 1] : def;
};

const OPTS = {
  accounts: path.resolve(__dirname, val("--accounts", "gt.txt")),
  cardFile: path.resolve(__dirname, val("--card", "cvc.txt")),
  proxyFile: path.resolve(__dirname, val("--proxy-file", "proxy.txt")),
  apiOut: path.resolve(__dirname, val("--out", "api.txt")),
  usedOut: path.resolve(__dirname, val("--used", "used.txt")),
  proxyUsed: path.resolve(__dirname, val("--proxy-used", "proxy-used.txt")),
  logDir: path.resolve(__dirname, val("--logs", "logs")),
  dumpDir: path.resolve(__dirname, val("--dumps", "dumps")),
  defaultPassword: val("--password", process.env.CW_PASSWORD || "Kiting@220219"),
  headless: (() => {
    const v = val("--headless", has("--headless") ? "true" : "false");
    return v === "false" ? false : v === "true" ? true : v; // true | false | "virtual"
  })(),
  noProxy: has("--no-proxy"),
  reuseUsed: has("--reuse-used"),
  only: val("--only", null),
  probe: has("--probe"),
  postal: val("--postal", "16024"),
  country: val("--country", "Indonesia"),
  keepOpen: has("--keep-open"),
  stepDelay: Number(val("--step-delay", "600")),
  stop: val("--stop", null),
  timeoutMs: Number(val("--timeout", String(7 * 60_000))),
  captchaWait: Number(val("--captcha-wait", has("--headless") ? "0" : "180")),
  maxAccounts: Number(val("--max", "0")),
};

fs.mkdirSync(OPTS.logDir, { recursive: true });
fs.mkdirSync(OPTS.dumpDir, { recursive: true });

// ---------------- log ----------------
const stamp = () => new Date().toISOString().replace("T", " ").slice(0, 19);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const log = (tag, ...a) => {
  const line = `[${stamp()}]${tag ? ` [${tag}]` : ""} ${a.join(" ")}`;
  console.log(line);
  try {
    fs.appendFileSync(path.join(OPTS.logDir, `run-${new Date().toISOString().slice(0, 10)}.log`), line + "\r\n");
  } catch {}
};
const short = (v, n = 8) => (v ? `${String(v).slice(0, n)}…${String(v).slice(-4)}` : "-");

// proxy SOCKS5 (Jack: tipe proxy = socks5)
function toSocksProxy(p) {
  if (!p) return undefined;
  const cfg = { server: `socks5://${p.host}:${p.port}` };
  if (p.username) cfg.username = p.username;
  if (p.password) cfg.password = p.password;
  return cfg;
}

// ---- Camoufox launch: fingerprint HUMAN + device-id FRESH tiap launch ----
// NOTE: Camoufox/Firefox + SOCKS5(auth) = NS_ERROR_UNKNOWN_PROXY_HOST, jadi pakai HTTP proxy.
async function launchBrowser(proxy) {
  const opts = {
    headless: OPTS.headless,
    os: "windows",
    humanize: true,
    locale: "en-US",
    geoip: false, // geoip nge-hang di Camoufox; tz system (Jakarta) udah match region-ID
    block_webrtc: true,
    exclude_addons: ["UBO"],
    disable_coop: true,
    i_know_what_im_doing: true,
    enable_cache: false, // cache/profile/device-id FRESH tiap akun
    window: [1200 + Math.floor(Math.random() * 360), 780 + Math.floor(Math.random() * 180)],
  };
  if (proxy) opts.proxy = toPlaywrightProxy(proxy);
  return Camoufox(opts);
}

function taggedError(code, msg) {
  const e = new Error(msg);
  e.code = code;
  return e;
}

// ---------------- gt.txt parser ----------------
function looksBase32(s) {
  return typeof s === "string" && s.length >= 16 && /^[A-Za-z2-7]+=*$/.test(s);
}
function splitUserSecret(line) {
  const t = line.trim();
  if (!t) return null;
  for (const sep of ["|", "\t", ";"]) {
    if (t.includes(sep)) {
      const parts = t.split(sep).map((s) => s.trim());
      if (parts.length >= 2 && parts[0]) return { username: parts[0], secret: parts[1], password: parts[2] || null };
    }
  }
  const candidates = [];
  for (let i = t.length - 1; i >= 0; i--) if (t[i] === "-" || t[i] === " " || t[i] === ":") candidates.push(i);
  for (const i of candidates) {
    const user = t.slice(0, i).trim();
    const secret = t.slice(i + 1).trim();
    if (user && looksBase32(secret)) return { username: user, secret, password: null };
  }
  return null;
}
function parseAccounts(file) {
  if (!fs.existsSync(file)) throw new Error(`accounts file nggak ada: ${file}`);
  const out = [];
  let bad = 0;
  for (const raw of fs.readFileSync(file, "utf8").split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith("#")) continue;
    const p = splitUserSecret(line);
    if (!p) { bad++; log("parse", `SKIP invalid: ${line.slice(0, 60)}`); continue; }
    let secret;
    try { secret = normalizeSecret(p.secret); } catch (e) { bad++; log("parse", `SKIP ${p.username}: ${e.message}`); continue; }
    out.push({ username: p.username, secret, password: p.password || OPTS.defaultPassword });
  }
  if (bad) log("parse", `${bad} baris dibuang`);
  return [...new Map(out.map((a) => [a.username.toLowerCase(), a])).values()];
}

// ---------------- card ----------------
function parseCard(file) {
  if (!fs.existsSync(file)) throw new Error(`cvc.txt nggak ada: ${file}`);
  const line = fs.readFileSync(file, "utf8").split(/\r?\n/).map((s) => s.trim()).find((s) => s && !s.startsWith("#"));
  if (!line) throw new Error("cvc.txt kosong");
  const parts = line.split(/[|,;/\s]+/).filter(Boolean);
  if (parts.length < 4) throw new Error(`format cvc.txt invalid: "${line}" (harus number|MM|YY|CVC)`);
  const [number, mm, yy, cvc] = parts;
  return { number: number.replace(/\D/g, ""), exp: `${mm.replace(/\D/g, "").padStart(2, "0")}${yy.replace(/\D/g, "").slice(-2)}`, cvc: cvc.replace(/\D/g, "") };
}

// ---------------- used-state ----------------
function loadUsed(file) {
  const map = new Map();
  if (!fs.existsSync(file)) return map;
  for (const line of fs.readFileSync(file, "utf8").split(/\r?\n/)) {
    const t = line.trim();
    if (!t || t.startsWith("#")) continue;
    const [username, status, detail] = t.split("|").map((s) => s.trim());
    if (username) map.set(username.toLowerCase(), { status, detail });
  }
  return map;
}
function markUsed(username, status, detail = "") {
  if (!fs.existsSync(OPTS.usedOut) || !fs.readFileSync(OPTS.usedOut, "utf8").includes("# username |")) {
    fs.appendFileSync(OPTS.usedOut, "# username | status | detail | timestamp\r\n");
  }
  fs.appendFileSync(OPTS.usedOut, `${username} | ${status} | ${String(detail).replace(/[\r\n|]/g, " ")} | ${new Date().toISOString()}\r\n`);
}
function saveKey(row) {
  if (!fs.existsSync(OPTS.apiOut) || !fs.readFileSync(OPTS.apiOut, "utf8").includes("# username |")) {
    fs.appendFileSync(OPTS.apiOut, "# username | api_key | created_at | proxy\r\n");
  }
  fs.appendFileSync(OPTS.apiOut, `${row.username} | ${row.key} | ${row.createdAt} | ${row.proxy}\r\n`);
}

// ---------------- proxy pointer (rotate, reset when exhausted) ----------------
function loadProxyUsed(file) {
  const set = new Set();
  if (!fs.existsSync(file)) return set;
  for (const line of fs.readFileSync(file, "utf8").split(/\r?\n/)) {
    const t = line.trim();
    if (!t || t.startsWith("#")) continue;
    set.add(t);
  }
  return set;
}
function markProxyUsed(raw) {
  fs.appendFileSync(OPTS.proxyUsed, raw + "\r\n");
}

// ---------------- IP uniqueness (tiap run IP harus beda) ----------------
const IP_FILE = () => path.resolve(__dirname, "ip-used.txt");
function loadIpUsed() {
  const f = IP_FILE();
  return fs.existsSync(f) ? new Set(fs.readFileSync(f, "utf8").split(/\r?\n/).map((s) => s.trim()).filter(Boolean)) : new Set();
}
function markIpUsed(ip) {
  fs.appendFileSync(IP_FILE(), ip + "\r\n");
}
async function getExitIP(page) {
  try {
    await page.goto("https://ipinfo.io/json", { waitUntil: "domcontentloaded", timeout: 25000 });
    const t = await page.locator("body").innerText().catch(() => "");
    let m = (t || "").match(/"ip"\s*:\s*"([^"]+)"/);
    if (!m) m = (t || "").match(/\d{1,3}(?:\.\d{1,3}){3}/);
    return m ? m[1] : null;
  } catch {
    return null;
  }
}

// ---------------- name generators (unique tiap run, lowercase) ----------------
const FIRST = ["rian","budi","agus","dwi","eko","yudi","hendra","wawan","dedi","rahmad","iqbal","fajar","galih","bayu","arif","taufik","doni","rizky","gita","putri","sari","dewi","indah","maya","lina","nisa","vina","yuni","tari","siti"];
const LAST = ["dikahus","saputra","pratama","wijaya","kurniawan","setiawan","hidayat","nugroho","firmansyah","maulana","ramadhan","fauzi","hermawan","susanto","gunawan","handoko","wahyudi","iskandar","siagian","nasution","sitompul","simbolon","panjaitan","atmaja","kusuma","pertiwi","lestari","anggraeni","oktaviani","maharani"];
const ORG_A = ["crimson","azure","iron","silent","rapid","nova","ember","lunar","titan","vertex","orbit","pixel","delta","quantum","echo","cobalt","amber","onyx","cyber","krypton","vortex","zenith","atlas","helix"];
const ORG_B = ["otter","falcon","lynx","raven","cobra","panda","heron","wolf","ibis","fox","moth","crane","kraken","jaguar","marlin","bison","gecko","osprey","tapir","lemur"];
// nama jalan gaya Indonesia
const STREETS = ["ahmad yani","durian beku","merdeka","sudirman","gatot subroto","diponegoro","hayam wuruk","teuku umar","kartini","imam bonjol","sisingamangaraja","pemuda","pelita","sejahtera","kamboja","anggrek","flamboyan","cempaka","kenari","mangga","rambutan","salak","duku","pisang","mahoni","melati","kenanga","cendrawasih","dahlia","teratai","mawar","seroja"];
const rint = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

function genNames(acc, used) {
  // nama + address UNIK tiap run (registry names-used.txt)
  const regFile = path.resolve(__dirname, "names-used.txt");
  const reg = fs.existsSync(regFile) ? new Set(fs.readFileSync(regFile, "utf8").split(/\r?\n/).map((s) => s.trim()).filter(Boolean)) : new Set();
  let fullName, address, org;
  for (let i = 0; i < 300; i++) {
    const h = crypto.createHash("sha1").update(`${acc.username}:${i}:${Date.now()}:${Math.random()}`).digest();
    fullName = (FIRST[h[0] % FIRST.length] + LAST[h[1] % LAST.length]).toLowerCase();
    // Org = nama lowercase + 2 angka (dipakai juga di sign up)
    org = `${fullName}${(h.readUInt16BE(6) % 90) + 10}`;
    const prefix = h[3] % 2 === 0 ? "jl" : "jalan";
    address = `${prefix} ${STREETS[h[2] % STREETS.length]}`;
    if (!reg.has(fullName) && !reg.has(address) && !reg.has(org)) break;
  }
  fs.appendFileSync(regFile, `${fullName}\r\n${address}\r\n${org}\r\n`);
  return { fullName, address, org };
}

// ======================= PLAYWRIGHT HELPERS =======================
async function visible(root, selectors, timeoutMs = 8000) {
  const list = Array.isArray(selectors) ? selectors : [selectors];
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    for (const sel of list) {
      try {
        const loc = root.locator(sel).first();
        if ((await loc.count().catch(() => 0)) && (await loc.isVisible().catch(() => false))) return loc;
      } catch {}
    }
    await sleep(150);
  }
  return null;
}
async function clickSel(root, selectors, { timeout = 10000, desc = "" } = {}) {
  const loc = await visible(root, selectors, timeout);
  if (!loc) throw new Error(`elemen nggak ketemu: ${desc || (Array.isArray(selectors) ? selectors[0] : selectors)}`);
  await loc.scrollIntoViewIfNeeded().catch(() => {});
  try { await loc.click({ timeout: 5000 }); } catch { await loc.click({ timeout: 5000, force: true }).catch(() => {}); }
  await sleep(OPTS.stepDelay);
  return loc;
}
async function bodyText(page) {
  return (await page.locator("body").innerText().catch(() => "")).replace(/\u00a0/g, " ");
}

// klik elemen (button/a/[role]) yang teksnya match regex; pilih area terkecil
async function clickText(page, re, { timeout = 12000, scope = null, desc = "", allowHref = false } = {}) {
  const deadline = Date.now() + timeout;
  const src = re.source;
  while (Date.now() < deadline) {
    const scopeEl = scope ? await scope.elementHandle().catch(() => null) : null;
    const handle = await page
      .evaluateHandle(
        ({ src, scope, allowHref, deny }) => {
          const root = scope || document;
          let reg, denyReg;
          try { reg = new RegExp(src, "i"); } catch { return null; }
          try { denyReg = new RegExp(deny, "i"); } catch { denyReg = null; }
          const sel = 'button, a, [role="button"], [role="tab"], [role="link"], [role="menuitem"], [role="menuitemradio"], [role="option"], input[type="submit"], input[type="button"], [class*="btn" i], [class*="button" i]';
          const els = Array.from(root.querySelectorAll(sel)).filter((el) => {
            if (el.tagName === "A" && !allowHref) {
              // tetap boleh kalau teksnya jelas tombol, tapi hindari link navigasi (docs/dll)
              const href = el.getAttribute("href") || "";
              if (/docs\.|privacy|terms|learn more|cookiepedia|console\.coreweave/i.test(href)) return false;
            }
            const txt = (el.innerText || el.value || el.getAttribute("aria-label") || "").replace(/\s+/g, " ").trim();
            if (!reg.test(txt)) return false;
            if (denyReg && denyReg.test(txt)) return false;
            const r = el.getBoundingClientRect();
            if (r.width < 4 || r.height < 4) return false;
            const st = getComputedStyle(el);
            if (st.visibility === "hidden" || st.display === "none" || st.pointerEvents === "none") return false;
            return true;
          });
          els.sort((a, b) => {
            const ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect();
            return ra.width * ra.height - rb.width * rb.height;
          });
          return els[0] || null;
        },
        { src, scope: scopeEl, allowHref, deny: "cancel|deny|reject|delete|remove|log out|sign out|unsubscribe" }
      )
      .catch(() => null);
    const el = handle ? handle.asElement() : null;
    if (el) {
      await el.scrollIntoViewIfNeeded().catch(() => {});
      try { await el.click({ timeout: 5000 }); } catch { await el.click({ timeout: 5000, force: true }).catch(() => {}); }
      await sleep(OPTS.stepDelay);
      return el;
    }
    await sleep(200);
  }
  throw new Error(`tombol "${re}" nggak ketemu${desc ? ` (${desc})` : ""}`);
}

async function dumpFail(username, kind, page, extra = {}) {
  const safe = String(username).replace(/[^a-z0-9._-]/gi, "_");
  const ts = new Date().toISOString().replace(/[:.]/g, "-");
  const base = path.join(OPTS.dumpDir, `${safe}-${kind}-${ts}`);
  try {
    if (page) {
      await page.screenshot({ path: `${base}.png`, fullPage: false }).catch(() => {});
      await fs.promises.writeFile(`${base}.html`, await page.content().catch(() => "")).catch(() => {});
      await fs.promises.writeFile(`${base}.txt`, await bodyText(page)).catch(() => {});
      const els = await page.evaluate(() => {
        const out = [];
        for (const el of document.querySelectorAll('button, a, input, select, textarea, [role="button"], [role="tab"], label, [data-testid]')) {
          const r = el.getBoundingClientRect();
          if (r.width < 2 || r.height < 2) continue;
          out.push({ tag: el.tagName, type: el.getAttribute("type") || "", name: el.getAttribute("name") || "", id: el.id || "", testid: el.getAttribute("data-testid") || "", ph: el.getAttribute("placeholder") || "", text: (el.innerText || el.value || "").replace(/\s+/g, " ").trim().slice(0, 80) });
        }
        return out;
      }).catch(() => []);
      await fs.promises.writeFile(`${base}.els.json`, JSON.stringify({ url: page.url(), els }, null, 2)).catch(() => {});
    }
    await fs.promises.writeFile(`${base}.json`, JSON.stringify(extra, null, 2)).catch(() => {});
  } catch {}
  return base;
}

// dump informatif (bukan error) buat mapping step
async function appendDump(username, kind, page) {
  const safe = String(username).replace(/[^a-z0-9._-]/gi, "_");
  const ts = new Date().toISOString().replace(/[:.]/g, "-");
  const base = path.join(OPTS.dumpDir, `${safe}-${kind}-${ts}`);
  try {
    await page.screenshot({ path: `${base}.png`, fullPage: false }).catch(() => {});
    await fs.promises.writeFile(`${base}.txt`, await bodyText(page)).catch(() => "");
    const els = await page.evaluate(() => {
      const out = [];
      for (const el of document.querySelectorAll('button, a, input, select, textarea, [role], label, [class*="card" i], [class*="option" i], [class*="Tile" i], form')) {
        const r = el.getBoundingClientRect();
        if (r.width < 2 || r.height < 2) continue;
        out.push({ tag: el.tagName, role: el.getAttribute("role") || "", type: el.getAttribute("type") || "", name: el.getAttribute("name") || "", id: el.id || "", ph: el.getAttribute("placeholder") || "", al: el.getAttribute("aria-label") || "", alb: el.getAttribute("aria-labelledby") || "", mr: el.getAttribute("aria-checked") || el.getAttribute("aria-selected") || "", text: (el.innerText || el.value || "").replace(/\s+/g, " ").trim().slice(0, 70) });
      }
      return out;
    }).catch(() => []);
    await fs.promises.writeFile(`${base}.els.json`, JSON.stringify({ url: page.url(), els }, null, 2)).catch(() => "");
    await fs.promises.writeFile(`${base}.html`, await page.content().catch(() => "")).catch(() => "");
    await fs.promises.writeFile(`${base}.json`, JSON.stringify({ url: page.url() }, null, 2)).catch(() => "");
  } catch {}
  return base;
}

// Pilih "kartu" opsi (bukan <button>): role=radio/option/button dulu, fallback klik teks.
async function selectOptionCard(page, textRe) {
  const src = textRe.source;
  const res = await page
    .evaluate((src) => {
      const reg = new RegExp(src, "i");
      const cands = Array.from(document.querySelectorAll('[role="radio"],[role="option"],button,label,[role="button"],[class*="card" i],[class*="option" i]')).filter((el) => {
        const t = (el.innerText || el.textContent || "").replace(/\s+/g, " ").trim();
        if (!reg.test(t)) return false;
        const r = el.getBoundingClientRect();
        return r.width >= 8 && r.height >= 8;
      });
      cands.sort((a, b) => { const ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect(); return ra.width * ra.height - rb.width * rb.height; });
      const el = cands[0];
      if (el) { el.scrollIntoView({ block: "center" }); el.click(); return { ok: true, via: "role", tag: el.tagName, role: el.getAttribute("role") || "" }; }
      return { ok: false };
    }, src)
    .catch((e) => ({ ok: false, err: e.message }));
  if (res.ok) return res;
  try {
    await page.getByText(textRe).first().click({ timeout: 4000, force: true });
    return { ok: true, via: "text" };
  } catch (e) {
    return { ok: false, err: e.message };
  }
}

async function findPage(context, predicate) {
  for (const p of context.pages()) { try { if (predicate(p.url())) return p; } catch {} }
  return null;
}

// cari Locator input berdasarkan teks label (React Aria)
async function locByLabel(page, labelText) {
  const lab = page.getByLabel(labelText, { exact: false }).first();
  if (await lab.count().catch(() => 0)) return lab;
  const id = await page
    .evaluate((t) => {
      const labels = Array.from(document.querySelectorAll("label"));
      const want = t.toLowerCase();
      const l = labels.find((x) => (x.textContent || "").trim().toLowerCase() === want) || labels.find((x) => (x.textContent || "").trim().toLowerCase().includes(want));
      return l ? l.id : null;
    }, labelText)
    .catch(() => null);
  if (id) {
    const inp = page.locator(`[aria-labelledby~="${id}"]`).first();
    if (await inp.count().catch(() => 0)) return inp;
  }
  return null;
}

// centang semua checkbox / role=checkbox yang belum checked (ToS, dll)
async function checkTos(page) {
  return page
    .evaluate(() => {
      let n = 0;
      for (const cb of document.querySelectorAll('input[type="checkbox"]')) {
        const r = cb.getBoundingClientRect();
        if (r.width < 2 || r.height < 2) continue;
        if (!cb.checked) { cb.click(); n++; }
      }
      for (const b of document.querySelectorAll('[role="checkbox"], button[name="checkbox"]')) {
        const r = b.getBoundingClientRect();
        if (r.width < 2 || r.height < 2) continue;
        if (b.getAttribute("aria-checked") !== "true") { b.click(); n++; }
      }
      return n;
    })
    .catch(() => 0);
}

// ---- Stripe card fill: WAIT iframe ready + ketik pelan (keystroke asli) ----
async function waitStripeFrames(page, tag, timeoutMs = 30000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const fr = page.frames().filter((f) => /stripe|__privateStripeFrame|elements/i.test((f.name() || "") + (f.url() || "")));
    for (const f of fr) {
      try {
        if ((await f.locator('input[autocomplete="cc-number"], input[name="number"], input[name="cardnumber"]').count()) > 0) return true;
      } catch {}
    }
    await sleep(500);
  }
  log(tag, "Stripe card iframe belum siap (timeout)");
  return false;
}

async function typeInto(loc, text, tag, label) {
  try {
    await loc.scrollIntoViewIfNeeded().catch(() => {});
    await loc.click({ timeout: 5000 }).catch(() => {});
    await sleep(350 + Math.random() * 350);
    await loc.press("Control+a").catch(() => {});
    await loc.press("Delete").catch(() => {});
    await sleep(250 + Math.random() * 250);
    // ketik super pelan, satu-satu, delay acak (human)
    const s = String(text);
    for (const ch of s) {
      try { await loc.press(ch, { delay: 45 }); } catch { try { await loc.type(ch); } catch {} }
      await sleep(150 + Math.random() * 170);
    }
    await sleep(500 + Math.random() * 400);
    const v = await loc.inputValue().catch(() => "");
    log(tag, `  ${label}: typed ${s.length}ch -> value ${v ? "len" + v.length : "EMPTY"}`);
    return !!v;
  } catch (e) {
    log(tag, `  ${label}: err ${e.message}`);
    return false;
  }
}

async function fillStripeCard(page, card, tag) {
  const mm = card.exp.slice(0, 2), yy = card.exp.slice(2);
  const ready = await waitStripeFrames(page, tag, 30000);
  if (!ready) return 0;
  let filled = 0;

  // kumpulkan semua frame yang punya input kartu (bisa 1 iframe gabungan atau 3 iframe terpisah)
  const numSel = 'input[autocomplete="cc-number"], input[name="number"], input[name="cardnumber"]';
  const expSel = 'input[autocomplete="cc-exp"], input[name="expiry"], input[name="exp-date"]';
  const cvcSel = 'input[autocomplete="cc-csc"], input[name="cvc"], input[name="cvcnumber"]';

  const findLoc = async (sel) => {
    for (const fr of page.frames()) {
      try { const l = fr.locator(sel).first(); if (await l.count()) return l; } catch {}
    }
    return null;
  };

  const numL = await findLoc(numSel);
  if (numL && (await typeInto(numL, card.number, tag, "card number"))) filled++;
  const expL = await findLoc(expSel);
  if (expL && (await typeInto(expL, `${mm}${yy}`, tag, "expiry"))) filled++;
  const cvcL = await findLoc(cvcSel);
  if (cvcL && (await typeInto(cvcL, card.cvc, tag, "cvc"))) filled++;

  log(tag, `Stripe card: ${filled} field(s) diisi (frames: ${page.frames().length})`);

  // read-back
  const rb = [];
  for (const fr of page.frames()) {
    try {
      for (const [label, sel] of [["num", numSel], ["exp", expSel], ["cvc", cvcSel]]) {
        const l = fr.locator(sel).first();
        if (await l.count()) { const v = await l.inputValue().catch(() => ""); rb.push(`${label}:${v ? "set(" + v.length + ")" : "EMPTY"}`); }
      }
    } catch {}
  }
  if (rb.length) log(tag, `card readback: ${rb.join(" ")}`);
  return filled;
}

// ---- react-select country -> target ----
async function selectCountryRV(page, country, tag) {
  try {
    const combo = page.locator('input[role="combobox"]').first();
    if (!(await combo.count())) { log(tag, "country combobox nggak ada"); return false; }
    await combo.scrollIntoViewIfNeeded().catch(() => {});
    await combo.click({ timeout: 5000 }).catch(() => {});
    await combo.fill("").catch(() => {});
    await combo.type(country, { delay: 70 }).catch(() => {});
    await sleep(1000);
    const opt = page.locator('[role="option"]').filter({ hasText: new RegExp(`^${country}$`, "i") }).first();
    if (await opt.count()) { await opt.click({ timeout: 4000 }).catch(() => {}); log(tag, `country -> ${country}`); return true; }
    await page.getByText(country, { exact: true }).first().click({ timeout: 3000 }).catch(() => {});
    log(tag, `country -> ${country} (fallback)`);
    return true;
  } catch (e) { log(tag, `country select err: ${e.message}`); return false; }
}

// ---- API key extraction ----
function looksKey(s) {
  const v = String(s || "").trim();
  if (v.length < 24 || v.length > 160) return false;
  if (/\s/.test(v)) return false;
  if (v.includes("-org") || v.includes("-team")) return false;
  if (!/[A-Za-z]/.test(v) || !/[0-9]/.test(v)) return false;
  if (/^[a-f0-9]{40}$/i.test(v)) return true;
  if (/^[A-Za-z0-9_-]{32,}$/.test(v)) return true;
  return false;
}
async function extractKey(page) {
  return page
    .evaluate(() => {
      const rx = /(wandb_v1_[A-Za-z0-9_-]{10,}|[a-f0-9]{40})/;
      for (const el of document.querySelectorAll("input, textarea")) { const m = (el.value || "").trim().match(rx); if (m) return m[1]; }
      for (const el of document.querySelectorAll('[data-test*="key" i],[data-testid*="key" i],code,pre')) { const m = (el.innerText || "").trim().match(rx); if (m) return m[1]; }
      const b = (document.body.innerText || "").match(rx);
      return b ? b[1] : null;
    })
    .catch(() => null);
}

async function waitForPage(context, predicate, timeoutMs = 45000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const p = await findPage(context, predicate);
    if (p) { await p.waitForLoadState("domcontentloaded").catch(() => {}); return p; }
    await sleep(250);
  }
  return null;
}

async function dismissCookies(page) {
  // klik Accept/Allow kalau ada
  for (const sel of ["#onetrust-accept-btn-handler", "#accept-recommended-btn-handler", 'button:has-text("Accept All")', 'button:has-text("Allow All")', 'button:has-text("Confirm My Choices")']) {
    try {
      const l = page.locator(sel).first();
      if ((await l.count()) && (await l.isVisible().catch(() => false))) { await l.click({ timeout: 2000 }).catch(() => {}); await sleep(300); }
    } catch {}
  }
  // SILANG (X) banner/cookie tiap muncul
  for (const sel of ["#onetrust-close-btn-handler", "#close-pc-btn-handler", 'button[aria-label="Close"]', 'button[aria-label="close"]']) {
    try {
      const l = page.locator(sel).first();
      if ((await l.count()) && (await l.isVisible().catch(() => false))) { await l.click({ timeout: 1500 }).catch(() => {}); await sleep(200); }
    } catch {}
  }
  // hapus overlay OneTrust yang nutupin
  await page.evaluate(() => {
    for (const id of ["onetrust-pc-sdk", "onetrust-banner-sdk", "onetrust-consent-sdk"]) {
      const el = document.getElementById(id);
      if (el) el.remove();
    }
    document.querySelectorAll(".onetrust-pc-dark-filter").forEach((e) => e.remove());
  }).catch(() => {});
}

// Isi input React Aria murni dari text LABEL (no name attr). React-safe native setter.
async function fillByLabel(page, labelText, value) {
  const ok = await page
    .evaluate(
      ({ labelText, value }) => {
        const labels = Array.from(document.querySelectorAll("label"));
        const want = labelText.toLowerCase();
        const lab = labels.find((l) => (l.textContent || "").trim().toLowerCase() === want) || labels.find((l) => (l.textContent || "").trim().toLowerCase().includes(want));
        if (!lab) return { ok: false, reason: "label nggak ketemu" };
        let inp = lab.htmlFor ? document.getElementById(lab.htmlFor) : null;
        if (!inp && lab.id) inp = document.querySelector(`[aria-labelledby~="${lab.id}"]`);
        if (!inp) inp = lab.querySelector("input, textarea");
        if (!inp) {
          let n = lab.nextElementSibling;
          while (n && !inp) { if (n.matches("input, textarea")) inp = n; n = n.nextElementSibling; }
        }
        if (!inp) return { ok: false, reason: "input nggak ketemu" };
        const proto = inp.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
        const setter = Object.getOwnPropertyDescriptor(proto, "value").set;
        inp.focus();
        setter.call(inp, value);
        inp.dispatchEvent(new Event("input", { bubbles: true }));
        inp.dispatchEvent(new Event("change", { bubbles: true }));
        inp.blur();
        return { ok: true, id: inp.id };
      },
      { labelText, value }
    )
    .catch((e) => ({ ok: false, reason: e.message }));
  return ok;
}

async function checkAllBoxes(page) {
  // React Aria checkbox: klik input sering nggak nempel → toggle manual + verifikasi
  return page
    .evaluate(() => {
      let n = 0;
      const fire = (el) => { try { el.dispatchEvent(new Event("input", { bubbles: true })); el.dispatchEvent(new Event("change", { bubbles: true })); } catch {} };
      const setChecked = (el, val) => {
        try { const d = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "checked").set; d.call(el, val); } catch {}
        fire(el);
      };
      for (const el of document.querySelectorAll('input[type="checkbox"]')) {
        const r = el.getBoundingClientRect();
        if (r.width < 2 || r.height < 2) continue;
        if (el.checked) continue;
        try { el.click(); } catch {}
        if (!el.checked) setChecked(el, true);
        if (!el.checked) {
          const lab = el.closest("label") || (el.id && document.querySelector(`label[for="${el.id}"]`));
          if (lab) { try { lab.click(); } catch {} }
        }
        if (!el.checked) setChecked(el, true); // paksa terakhir
        n++;
      }
      for (const el of document.querySelectorAll('[role="checkbox"]')) {
        const r = el.getBoundingClientRect();
        if (r.width < 2 || r.height < 2) continue;
        if (el.getAttribute("aria-checked") === "true") continue;
        try { el.click(); } catch {}
        n++;
      }
      return n;
    })
    .catch(() => 0);
}

// Pilih kartu opsi "What are you working on?" — verifikasi aria-selected + keyboard fallback
async function selectWorkingOn(page, textRe, tag) {
  const src = textRe.source;
  const handle = await page
    .evaluateHandle((src) => {
      const reg = new RegExp(src, "i");
      const cands = Array.from(document.querySelectorAll('[role="row"],[role="radio"],[role="option"],[role="gridcell"],button,label,[class*="card" i],[class*="Tile" i]')).filter((el) => {
        const t = (el.innerText || "").replace(/\s+/g, " ").trim();
        if (!reg.test(t)) return false;
        const r = el.getBoundingClientRect();
        return r.width > 8 && r.height > 8;
      });
      cands.sort((a, b) => { const ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect(); return ra.width * ra.height - rb.width * rb.height; });
      return cands[0] || null;
    }, src)
    .catch(() => null);
  const el = handle ? handle.asElement() : null;
  if (!el) return { ok: false, reason: "no-elem" };
  const isSel = () =>
    page
      .evaluate(() => Array.from(document.querySelectorAll('[role="row"],[role="radio"],[role="option"],[role="gridcell"]')).some((r) => r.getAttribute("aria-selected") === "true" || r.getAttribute("aria-checked") === "true"))
      .catch(() => false);
  await el.scrollIntoViewIfNeeded().catch(() => {});
  await el.click({ timeout: 5000 }).catch(() => {});
  await sleep(900);
  if (await isSel()) return { ok: true, via: "click" };
  await el.evaluate((e) => e.focus && e.focus()).catch(() => {});
  await page.keyboard.press("Space").catch(() => {});
  await sleep(700);
  if (await isSel()) return { ok: true, via: "space" };
  await page.keyboard.press("Enter").catch(() => {});
  await sleep(700);
  if (await isSel()) return { ok: true, via: "enter" };
  return { ok: false, reason: "not-selected" };
}

// ======================= STEPS =======================

// STEP 1-3: id.coreweave.com -> Sign up tab -> Continue with GitHub
async function stepSignup(context, tag) {
  const page = await context.newPage();
  await page.goto("https://id.coreweave.com/login?next=%2F", { waitUntil: "domcontentloaded", timeout: 60000 });
  await sleep(4000);
  await dismissCookies(page);

  // Klik tab "Sign up" (role=tab / id *tab-signup)
  const tab = await visible(page, ['[role="tab"]:has-text("Sign up")', '[id*="tab-signup"]', 'div:has-text("Sign up")'], 8000);
  if (tab) {
    await tab.click({ timeout: 5000 }).catch(() => {});
    await sleep(1500);
  } else {
    await clickText(page, /^sign ?up$/i, { timeout: 5000, allowHref: true }).catch(() => {});
    await sleep(1500);
  }
  log(tag, "tab Sign up diklik");

  // Klik "Continue with GitHub"
  const gh = await visible(page, [
    'button:has-text("Continue with GitHub")',
    'button:has-text("GitHub")',
    '[role="button"]:has-text("GitHub")',
  ], 10000);
  if (!gh) throw new Error("tombol Continue with GitHub nggak ketemu");
  await gh.click({ timeout: 6000 }).catch(async () => await gh.click({ timeout: 6000, force: true }).catch(() => {}));
  await sleep(3000);

  const isGh = (u) => /(^|\.)github\.com$/.test((() => { try { return new URL(u).hostname.toLowerCase(); } catch { return ""; } })());
  const ghPage = await waitForPage(context, isGh, 45000);
  const target = ghPage || page;
  log(tag, `GitHub page: ${target.url().slice(0, 100)}`);
  return target;
}

// STEP 4-6: GitHub login + TOTP + skip 2fa settings
async function stepGithubLogin(page, acc, tag) {
  await page.waitForLoadState("domcontentloaded").catch(() => {});
  const isGh = /(^|\.)github\.com$/.test((() => { try { return new URL(page.url()).hostname.toLowerCase(); } catch { return ""; } })());

  if (/\/(login\/oauth\/authorize|apps\/.+\/authorizations|sessions\/two-factor)/.test(page.url())) {
    log(tag, "GitHub langsung ke authorize/2fa — skip form login");
    return page;
  }
  if (!isGh) throw new Error(`bukan halaman GitHub: ${page.url()}`);

  const userField = await visible(page, ['#login_field', 'input[name="login"]', 'input[autocomplete="username"]'], 30000);
  if (!userField) {
    if (/\/login\/oauth\/authorize/.test(page.url())) return page;
    throw new Error(`form login GitHub nggak ketemu (url=${page.url()})`);
  }

  await userField.fill(acc.username);
  await sleep(300);
  const passField = await visible(page, ['#password', 'input[name="password"]', 'input[type="password"]'], 8000);
  if (!passField) throw new Error("field password GitHub nggak ketemu");
  await passField.fill(acc.password);
  await sleep(300);

  await clickSel(page, ['input[type="submit"][name="commit"]', 'button[type="submit"]', 'button:has-text("Sign in")'], { timeout: 8000, desc: "submit GH login" });
  await sleep(3000);

  let body = await bodyText(page);
  if (/incorrect username or password|invalid username or password/i.test(body)) throw taggedError("BAD_CREDENTIALS", "username/password GitHub salah");

  if (/verify you are human|captcha|are you a robot/i.test(body)) {
    if (OPTS.captchaWait > 0 && !OPTS.headless) {
      log(tag, `CAPTCHA — solve manual (${OPTS.captchaWait}s)`);
      const dl = Date.now() + OPTS.captchaWait * 1000;
      while (Date.now() < dl) { await sleep(2000); if (!/verify you are human|captcha/i.test(await bodyText(page))) break; }
    } else {
      throw taggedError("CAPTCHA", "GitHub CAPTCHA (jalanin headed biar bisa solve)");
    }
  }

  // 2FA TOTP
  const otpSel = ['#app_totp', 'input[name="app_totp"]', 'input[name="otp"]', 'input[name*="otp" i]', 'input[id*="otp" i]', 'input[autocomplete="one-time-code"]', '#otp', 'input[inputmode="numeric"]', 'input[type="text"][maxlength="6"]'];
  if (!(await visible(page, otpSel, 2500))) {
    await clickText(page, /authenticator app|authenticator|enter code|use.*code|verification code/i, { timeout: 5000 }).catch(() => {});
    await sleep(1200);
  }
  for (let attempt = 0; attempt < 3; attempt++) {
    const otpField = await visible(page, otpSel, attempt === 0 ? 14000 : 5000);
    if (!otpField) break;
    const fresh = freshTotp(acc.secret, { minLeft: 4 });
    if (fresh.waitMs) { log(tag, `TOTP mepet (${fresh.left}s) — tunggu ${fresh.waitMs}ms`); await sleep(fresh.waitMs); }
    const code = fresh.code || totp(acc.secret);
    log(tag, `isi TOTP ${code.slice(0, 3)}*** (sisa ${secondsLeft()}s)`);
    await otpField.fill(code);
    await sleep(2200);
    let still = await visible(page, otpSel, 1500);
    if (still) { await otpField.press("Enter").catch(() => {}); await sleep(3500); still = await visible(page, otpSel, 1500); }
    body = await bodyText(page);
    if (!still) break;
    if (/two-factor authentication failed|code.*invalid|invalid.*code/i.test(body)) { log(tag, `TOTP ditolak attempt ${attempt + 2}`); await sleep(2500); continue; }
    break;
  }

  body = await bodyText(page);
  if (/verify a device|check your email|device verification/i.test(body) && /github\.com\/sessions/.test(page.url())) throw taggedError("NEEDS_EMAIL", "GitHub minta device verification email");
  if (/account.*suspended|suspended/i.test(body)) throw taggedError("SUSPENDED", "akun GitHub suspended");
  if (/two-factor authentication failed|code.*invalid/i.test(body)) throw taggedError("BAD_2FA", "TOTP ditolak (secret salah?)");
  if (/passkey/i.test(body) && !/authenticator app/i.test(body) && !(await visible(page, otpSel, 800))) throw taggedError("NEEDS_PASSKEY", "GitHub cuma nawarin passkey");

  // skip halaman 2FA settings (gass.txt: klik skip 2fa)
  body = await bodyText(page);
  if (/two-factor authentication \(2fa\) settings|2fa settings|secure your account/i.test(body)) {
    const btn = await clickText(page, /skip|not now|later|do this later|i'll do it later/i, { timeout: 6000 }).catch(() => null);
    if (btn) { log(tag, "skip halaman 2FA settings"); await sleep(2000); }
    else log(tag, "halaman 2FA settings muncul tapi tombol skip nggak ada");
  }
  return page;
}

// STEP 7: GitHub OAuth authorize for Weights & Biases
async function stepGithubAuthorize(context, tag) {
  const isGh = (u) => { try { return /(^|\.)github\.com$/.test(new URL(u).hostname.toLowerCase()); } catch { return false; } };
  const isBack = (u) => /wandb\.(ai|auth0\.com)|coreweave\.com/.test(u);
  const start = Date.now();
  let clicks = 0;
  const ghPage = await waitForPage(context, isGh, 20000);
  if (!ghPage) {
    // sudah pernah authorize -> GitHub skip consent & langsung redirect balik
    const back = (await waitForPage(context, isBack, 30000)) || context.pages().slice(-1)[0];
    log(tag, `authorize di-skip (langsung redirect): ${back.url().slice(0, 90)}`);
    return back;
  }
  const target = ghPage;
  if (!target) throw new Error("halaman authorize GitHub nggak ketemu");

  while (Date.now() - start < 120000) {
    if (!isGh(target.url())) { log(tag, `authorize: pindah ke ${target.url().slice(0, 90)}`); break; }
    const res = await target
      .evaluate((allowClick) => {
        const norm = (s) => String(s || "").replace(/\s+/g, " ").trim();
        const nodes = Array.from(document.querySelectorAll('button, input[type="submit"], input[type="button"], [role="button"]'));
        const scored = [];
        for (const el of nodes) {
          const t = norm((el.innerText || "") + " " + (el.value || "") + " " + (el.getAttribute("aria-label") || "") + " " + (el.getAttribute("data-testid") || ""));
          if (/cancel|deny|reject|not now/i.test(t)) continue;
          const isAuth = el.name === "authorize" || el.id === "js-oauth-authorize-btn" || /oauth-authorize-button/i.test(el.getAttribute("data-testid") || "") || /authorize|allow/i.test(t);
          if (!isAuth) continue;
          let score = 0;
          if (el.name === "authorize") score += 20;
          if (el.id === "js-oauth-authorize-btn") score += 20;
          if (/oauth-authorize-button/i.test(el.getAttribute("data-testid") || "")) score += 20;
          if (/^authorize/i.test(t)) score += 12;
          if (/authorize|allow/i.test(t)) score += 8;
          if (/wandb|weights|& ?biases/i.test(t)) score += 6;
          if (/btn-primary|primary/i.test(String(el.className))) score += 2;
          const r = el.getBoundingClientRect();
          scored.push({ el, t, score, vis: r.width > 0 && r.height > 0, disabled: !!el.disabled || el.getAttribute("aria-disabled") === "true" });
        }
        scored.sort((a, b) => b.score - a.score);
        const hit = scored.find((x) => x.vis && !x.disabled);
        if (hit) {
          if (!allowClick) return { found: true, clicked: false, waiting: true, text: hit.t, url: location.href };
          hit.el.scrollIntoView({ block: "center" });
          hit.el.click();
          return { found: true, clicked: true, text: hit.t, url: location.href };
        }
        const dis = scored.find((x) => x.vis && x.disabled);
        return { found: !!dis, clicked: false, disabled: !!dis, text: dis?.t || "", buttons: nodes.map((el) => norm(el.innerText || el.value)).filter(Boolean).slice(0, 15) };
      }, clicks < 1)
      .catch((e) => ({ found: false, clicked: false, error: e.message }));

    if (res.clicked) { clicks++; log(tag, `klik Authorize: "${res.text}"`); await sleep(3000); }
    else if (res.found && res.disabled && clicks === 0) {
      await target.evaluate(() => {
        const b = document.querySelector('button[name="authorize"], #js-oauth-authorize-btn, button[data-testid="oauth-authorize-button"]');
        if (b) { b.disabled = false; b.removeAttribute("aria-disabled"); b.click(); return; }
        const f = Array.from(document.forms).find((f) => /authorize/i.test(f.action) || f.querySelector('[name="authorize"]'));
        if (f) f.requestSubmit ? f.requestSubmit() : f.submit();
      }).catch(() => {});
      clicks++; log(tag, "authorize button disabled — force klik"); await sleep(3000);
    } else if (res.found && res.waiting) {
      if (Date.now() - start < 3000) log(tag, `authorize udah diklik ("${res.text}") — nunggu redirect`);
    } else {
      // scroll + submit form fallback
      await target.evaluate((y) => window.scrollTo(0, y), clicks ? 0 : 400).catch(() => {});
      if (clicks === 0 && Date.now() - start > 6000) {
        const sub = await target.evaluate(() => {
          const f = Array.from(document.forms).find((f) => /authorize/i.test(f.action) || f.querySelector('[name="authorize"]'));
          if (!f) return false; f.requestSubmit ? f.requestSubmit() : f.submit(); return true;
        }).catch(() => false);
        if (sub) { clicks++; log(tag, "fallback submit form authorize"); }
      }
    }
    await sleep(700);
    if (!isGh(target.url())) break;
  }

  // tunggu redirect balik ke wandb/coreweave
  const back = await waitForPage(context, (u) => /wandb\.(ai|auth0\.com)|coreweave\.com/.test(u), 60000);
  log(tag, `setelah authorize: ${(back || target).url().slice(0, 110)}`);
  return back || target;
}

// STEP 8-10: W&B/CoreWeave onboarding — "Sign up for an account" form
//   (Full name + Organization or Institution + username + ToS + Continue)
//   lalu step lanjutan (Create your organization / What are you working on?)
async function stepWandbSignup(context, page, acc, tag) {
  let p = await waitForPage(context, (u) => /wandb\.(ai|auth0\.com)|coreweave\.com/.test(u), 60000) || page;
  await p.waitForLoadState("domcontentloaded").catch(() => {});
  await p.waitForLoadState("networkidle", { timeout: 30000 }).catch(() => {});
  await sleep(4000);
  await dismissCookies(p);

  const { fullName, org, address } = acc.names;
  acc.fullName = fullName;
  acc.org = org;
  acc.address = address;

  // tunggu form onboarding (label "Full name")
  let hasForm = false;
  for (let i = 0; i < 8; i++) {
    const body = await bodyText(p);
    if (/sign up for an account|full name|organization or institution/i.test(body)) { hasForm = true; break; }
    await sleep(2000);
  }
  if (!hasForm) {
    // sudah lewat onboarding? langsung lanjut
    log(tag, "form onboarding nggak muncul — mungkin udah lewat");
  } else {
    const r1 = await fillByLabel(p, "Full name", fullName);
    const r2 = await fillByLabel(p, "Organization or Institution", org);
    // ketik pelan selayaknya human (override nilai hasil fillByLabel)
    const nameLoc = await locByLabel(p, "Full name");
    if (nameLoc) await typeInto(nameLoc, fullName, tag, "Full name");
    const orgLoc = await locByLabel(p, "Organization or Institution");
    if (orgLoc) await typeInto(orgLoc, org, tag, "Organization");
    log(tag, `Full name="${fullName}" (${r1.ok ? "ok" : r1.reason}) | Org="${org}" (${r2.ok ? "ok" : r2.reason})`);

    // Professional (default) kalau ada kartu pilihan
    await clickText(p, /^professional$/i, { timeout: 1500 }).catch(() => {});

    const nBoxes = await checkAllBoxes(p);
    log(tag, `checkbox dicentang: ${nBoxes}`);

    await clickText(p, /^continue$/i, { timeout: 10000, desc: "Continue signup" }).catch(async () => {
      await clickSel(p, ['button[type="submit"]'], { timeout: 6000 }).catch(() => {});
    });
    await sleep(4500);
  }

  // Step lanjutan: loop handle prompt yang dikenal + dump tiap transisi
  for (let i = 0; i < 6; i++) {
    const url = p.url();
    if (/forge\.coreweave\.com/.test(url) && !/onboarding/i.test(url)) { log(tag, `sudah onboarded -> ${url.slice(0, 90)}`); break; }
    if (/\/account-settings|\/home|\/projects|\/dashboard/.test(url) && !/\/onboarding/.test(url)) { log(tag, `onboarding selesai -> ${url.slice(0, 90)}`); break; }
    const body = await bodyText(p);

    if (/what are you working on/i.test(body)) {
      log(tag, "step: What are you working on?");
      if (i === 0) await appendDump(acc.username, "whatworkingon", p).catch(() => {});
      const sel = await selectWorkingOn(p, /train and fine-?tune models/i, tag);
      log(tag, `pilih opsi: ${JSON.stringify(sel)}`);
      await sleep(1000);
      await clickText(p, /^continue$/i, { timeout: 8000 }).catch(() => {});
      // tunggu redirect + halaman benar-benar terload
      for (let w = 0; w < 12; w++) { await sleep(2500); if (!/onboarding/i.test(p.url())) { log(tag, `redirect ke ${p.url().slice(0, 80)}`); break; } }
      await p.waitForLoadState("networkidle", { timeout: 30000 }).catch(() => {});
      await sleep(2500);
      continue;
    }
    if (/create your organization|name your organization|organization name/i.test(body)) {
      log(tag, "step: Create your organization");
      await appendDump(acc.username, "onboarding-org", p).catch(() => {});
      await clickText(p, /^continue$/i, { timeout: 6000 }).catch(() => {});
      await sleep(3000);
      continue;
    }
    if (/invite|teammates/i.test(body)) {
      log(tag, "step: invite (skip)");
      await clickText(p, /skip|^continue$|not now|no thanks/i, { timeout: 5000 }).catch(() => {});
      await sleep(2500);
      continue;
    }
    // fallback: klik Continue/Get started kalau ada
    const clicked = await clickText(p, /^continue$|^next$|^get started$|^finish$|^done$|^go to (forge|home)$/i, { timeout: 3500 }).catch(() => null);
    if (!clicked) { log(tag, `onboarding: nggak ada aksi jelas di ${url.slice(0, 80)} — stop loop`); break; }
    await sleep(3000);
  }
  await appendDump(acc.username, "post-onboarding", p).catch(() => {});
  log(tag, `setelah onboarding: ${p.url().slice(0, 100)}`);
  return p;
}

// STEP 11-21: Billing -> Inference Activate (card) -> API Keys -> New key -> copy
async function stepBillingAndKey(context, page, acc, tag) {
  // pastikan di HOME forge (bukan /account-settings) + full load
  let p = page;
  if (!/forge\.coreweave\.com/.test(p.url())) {
    p = (await waitForPage(context, (u) => /forge\.coreweave\.com/.test(u), 5000)) || p;
  }
  if (/\/account-settings/.test(p.url()) || !/forge\.coreweave\.com/.test(p.url())) {
    await p.goto("https://forge.coreweave.com/", { waitUntil: "domcontentloaded", timeout: 60000 }).catch(() => {});
  }
  await sleep(2500);
  await dismissCookies(p);
  log(tag, "== fase BILLING (via menu profile) ==");

  let activated = false;

  // === BILLING: activate Inference pay-as-you-go (validasi WAJIB sebelum API key) ===
  const act = await billingActivate(p, acc, tag);
  if (!act.ok) throw taggedError("ACTIVATION_FAIL", `Inference belum aktif (${act.reason || "?"})`);
  activated = true;
  log(tag, "Inference pay-as-you-go AKTIF ✔ lanjut buat API key");
  await appendDump(acc.username, "billing-ok", p).catch(() => {});

  // API Keys: klik TAB nav di sebelah Billing (bukan profile menu)
  let apiKey = null;
  for (let attempt = 0; attempt < 3 && !apiKey; attempt++) {
    await clickNavTab(p, "API Keys", tag);
    await sleep(2500);
    await appendDump(acc.username, "apikeys-tab", p).catch(() => {});

    // "+ New key"
    const newBtn = p.locator('button:has-text("New key")').first();
    if (await newBtn.count()) await newBtn.click({ timeout: 8000 }).catch(() => {});
    else await clickText(p, /^\+?\s*new key$|new key/i, { timeout: 6000 }).catch(() => {});
    await sleep(2500);
    await appendDump(acc.username, "apikeys-newkey", p).catch(() => {});
    await dismissCookies(p);

    // isi Name (opsional) via data-test
    const nameIn = p.locator('[data-test="api-key-description-input"]').last();
    if (await nameIn.count()) await nameIn.fill(`fox-${Date.now().toString(36)}`).catch(() => {});
    else {
      const alt = p.locator('input[type="text"]:not([role="combobox"]), input:not([type]):not([role="combobox"])').last();
      if (await alt.count()) await alt.fill(`fox-${Date.now().toString(36)}`).catch(() => {});
    }
    await sleep(500);
    await dismissCookies(p);

    // klik "Create API key" via data-test (paling reliable)
    let advanced = false;
    const cbtn = p.locator('[data-test="create-api-key-button"]').last();
    if (await cbtn.count()) {
      await cbtn.click({ timeout: 6000 }).catch(async () => { await cbtn.click({ timeout: 6000, force: true }).catch(() => {}); });
      await sleep(2500);
      advanced = !/Step 1 of 2/i.test(await bodyText(p));
    }
    if (!advanced) {
      await p.getByRole("button", { name: /create api key/i }).last().click({ force: true, timeout: 5000 }).catch(() => {});
      await sleep(2500);
      advanced = !/Step 1 of 2/i.test(await bodyText(p));
    }
    if (!advanced) {
      await (await nameIn.count() ? nameIn : p.locator("input").last()).press("Enter").catch(() => {});
      await sleep(3000);
    }
    await sleep(3000);
    await appendDump(acc.username, "apikeys-step2", p).catch(() => {});

    apiKey = await extractKey(p);
    if (!apiKey) {
      await clickText(p, /copy/i, { timeout: 3000 }).catch(() => {});
      await sleep(1000);
      try {
        const clip = await p.evaluate(() => navigator.clipboard.readText().catch(() => null)).catch(() => null);
        const m = (clip || "").match(/wandb_v1_[A-Za-z0-9_-]{10,}|[a-f0-9]{40}/);
        if (m) apiKey = m[0];
      } catch {}
    }
    if (apiKey) {
      // klik Done kalau ada
      await clickText(p, /^done$/i, { timeout: 4000 }).catch(() => {});
      log(tag, `API key ke-capture: ${short(apiKey, 12)} (len ${apiKey.length})`);
      break;
    }
    if (!apiKey) {
      const d = await dumpFail(acc.username, `apikey-${attempt + 1}`, p, { url: p.url() });
      log(tag, `API key belum kebaca (attempt ${attempt + 1}) — dump ${d}`);
      await sleep(1500);
    }
  }

  if (!apiKey) throw taggedError("KEY_FAIL", "API key nggak berhasil diambil");
  log(tag, `API KEY didapat: ${short(apiKey, 6)}`);
  return { apiKey, activated };
}

// ======================= BILLING STATE MACHINE =======================
// Status Inference: ada tombol Activate = BELUM aktif. nggak ada + "View usage" = AKTIF.
async function inferStatus(page) {
  return page
    .evaluate(() => {
      const norm = (s) => String(s || "").replace(/\s+/g, " ").trim();
      const body = norm(document.body.innerText);
      const hasActivate = Array.from(document.querySelectorAll('button,[role="button"]')).some((b) => /^activate$/i.test(norm(b.innerText || b.value)));
      if (hasActivate) return { active: false, ref: "has-activate" };
      if (/pay-as-you-go activated|successfully activated/i.test(body)) return { active: true, ref: "activated-text" };
      if (/no billable usage/i.test(body)) return { active: true, ref: "no-billable" };
      if (/view usage/i.test(body) && !/not activated/i.test(body)) return { active: true, ref: "view-usage" };
      return { active: false, ref: "unknown" };
    })
    .catch(() => ({ active: false, ref: "err" }));
}

async function clickInferenceActivate(page) {
  return page
    .evaluate(() => {
      const norm = (s) => String(s || "").replace(/\s+/g, " ").trim();
      const btns = Array.from(document.querySelectorAll('button,[role="button"]')).filter((b) => /^activate$/i.test(norm(b.innerText || b.value)));
      if (!btns.length) return false;
      // Activate pertama = baris Inference (Inference selalu di atas Sandbox)
      btns[0].scrollIntoView({ block: "center" });
      btns[0].click();
      return true;
    })
    .catch(() => false);
}

// buka menu profile (ikon kanan atas) -> klik item (Billing / API Keys). TUNGGU full load.
async function openViaProfileMenu(p, itemRe, tag) {
  if (!/forge\.coreweave\.com/.test(p.url())) {
    log(tag, "buka forge home...");
    await p.goto("https://forge.coreweave.com/", { waitUntil: "domcontentloaded", timeout: 60000 }).catch(() => {});
    await p.waitForLoadState("domcontentloaded").catch(() => {});
    await sleep(2500);
  }
  await dismissCookies(p);
  const prof = p.locator('button[aria-label="Open account selector"], button:has-text("-org")').first();
  if (!(await prof.count().catch(() => 0))) { log(tag, "profile button kanan atas nggak ketemu"); return false; }
  await prof.scrollIntoViewIfNeeded().catch(() => {});
  log(tag, "klik ikon profile kanan atas...");
  await prof.click({ timeout: 8000 }).catch(() => {});
  // tunggu dropdown menu kebuka
  await visible(p, ['[role="menu"]', '[role="menuitem"]', 'text=/Billing/i', 'text=/API Keys/i'], 12000).catch(() => null);
  await sleep(900);
  await appendDump("menu", "profile-menu", p).catch(() => {});
  log(tag, "klik item menu...");
  await clickText(p, itemRe, { timeout: 10000 }).catch(() => {});
  await p.waitForLoadState("domcontentloaded").catch(() => {});
  await sleep(2500);
  await dismissCookies(p);
  log(tag, `setelah klik item: ${p.url().slice(0, 90)}`);
  return true;
}

// klik TAB nav kiri (Users/Teams/Service Accounts/API Keys/Billing/...) — selector bener
async function clickNavTab(p, name, tag) {
  await dismissCookies(p);
  const cands = [
    `a[role="tab"]:has-text("${name}")`,
    `[role="tab"]:has-text("${name}")`,
    `[id*="trigger-${name}"]`,
    `a:has-text("${name}")`,
    `button:has-text("${name}")`,
  ];
  for (const sel of cands) {
    try {
      const loc = p.locator(sel).first();
      if ((await loc.count().catch(() => 0)) && (await loc.isVisible().catch(() => false))) {
        await loc.scrollIntoViewIfNeeded().catch(() => {});
        await loc.click({ timeout: 8000 }).catch(async () => { await loc.click({ timeout: 8000, force: true }).catch(() => {}); });
        await p.waitForLoadState("networkidle", { timeout: 20000 }).catch(() => {});
        await sleep(2500);
        if (new RegExp(name, "i").test(await bodyText(p))) { log(tag, `klik nav tab "${name}"`); return true; }
      }
    } catch {}
  }
  await clickText(p, new RegExp(`^${name}$`, "i"), { timeout: 8000 }).catch(() => {});
  await sleep(2500);
  return false;
}

async function ensureBilling(p, acc, tag, forceReload = false) {
  for (let tryN = 0; tryN < 3; tryN++) {
    if (tryN > 0 || forceReload || !/\/billing/.test(p.url())) {
      if (tryN > 0 || !/forge\.coreweave\.com/.test(p.url())) {
        log(tag, "ke forge home...");
        await p.goto("https://forge.coreweave.com/", { waitUntil: "domcontentloaded", timeout: 60000 }).catch(() => {});
        await sleep(2500);
      }
      await dismissCookies(p);
      log(tag, `buka Billing via menu profile (try ${tryN + 1}/3)...`);
      await openViaProfileMenu(p, /^billing$/i, tag);
    }
    await sleep(2500);
    await dismissCookies(p);
    log(tag, `tunggu konten Billing (try ${tryN + 1}/3)...`);
    const ready = await visible(p, ['button:has-text("Activate")', 'text=/Pay-as-you-go/i', 'text=/Current usage/i'], 35000);
    if (ready) { log(tag, "konten Billing muncul ✔"); return true; }
    log(tag, `konten billing belum muncul (try ${tryN + 1}/3)`);
  }
  return false;
}

// cari slug entity/org dari URL /account-settings/<entity>  (skip nama tab yg dikenal)
async function resolveEntity(p, tag) {
  const tabNames = /^(settings|billing|api-keys|users|teams|service-accounts|usage|home|projects|profile)$/i;
  const fromUrl = (u) => { const m = u.match(/\/account-settings\/([^/?#]+)/); return m && !tabNames.test(m[1]) ? m[1] : null; };
  let e = fromUrl(p.url());
  if (e) return e;
  await p.goto("https://forge.coreweave.com/account-settings", { waitUntil: "domcontentloaded", timeout: 60000 }).catch(() => {});
  await sleep(5000);
  e = fromUrl(p.url());
  if (e) return e;
  try {
    const txt = await p.locator('button:has-text("-org")').first().textContent({ timeout: 5000 });
    const mm = (txt || "").match(/([a-z0-9][a-z0-9-]{2,}-org)\b/i);
    if (mm) return mm[1];
  } catch {}
  const b = await bodyText(p);
  const bm = b.match(/([a-z0-9][a-z0-9-]{2,}-org)\b/i);
  return bm ? bm[1] : null;
}

async function fillBillingForm(p, acc, tag) {
  // isi field dengan URUTAN RANDOM (selayaknya human)
  const ops = [
    async () => { const l = p.locator('input[placeholder="Name on card"]').first(); if (await l.count()) await typeInto(l, acc.fullName || "budi", tag, "name"); },
    async () => { const l = p.locator('input[placeholder="Address on card"]').first(); if (await l.count()) await typeInto(l, acc.address || "jl durian beku", tag, "address"); },
    async () => { const l = p.locator('input[placeholder="Postal code"]').first(); if (await l.count()) await typeInto(l, OPTS.postal, tag, "postal"); },
    async () => { await selectCountryRV(p, OPTS.country, tag); },
    async () => { await fillStripeCard(p, acc.card, tag); },
  ];
  for (let i = ops.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [ops[i], ops[j]] = [ops[j], ops[i]]; }
  log(tag, `billing: isi field urutan random -> ${ops.map((_, i) => i).join(",")}`);
  for (const op of ops) { await sleep(500 + Math.random() * 900); await op().catch(() => {}); }
  const tos = await checkTos(p);
  log(tag, `billing form selesai tos=${tos}`);
}

// Return { ok:true } kalau Inference aktif (validated), atau { ok:false, reason }
async function billingActivate(p, acc, tag) {
  for (let attempt = 0; attempt < 3; attempt++) {
    const loaded = await ensureBilling(p, acc, tag, attempt > 0);
    if (!loaded) log(tag, "billing belum kelar load — coba refresh");

    // tunggu tombol Activate (konten Forge load di dalam halaman)
    let actBtn = await visible(p, ['button:has-text("Activate")'], 30000);
    for (let w = 0; w < 3 && !actBtn; w++) {
      log(tag, `tombol Activate belum muncul (wait ${w + 1}) — refresh halaman`);
      await p.reload({ waitUntil: "domcontentloaded", timeout: 60000 }).catch(() => {});
      await p.waitForLoadState("networkidle", { timeout: 30000 }).catch(() => {});
      await sleep(4000);
      await dismissCookies(p);
      actBtn = await visible(p, ['button:has-text("Activate")'], 30000);
    }

    let st = await inferStatus(p);
    log(tag, `[billing ${attempt + 1}/3] status: ${st.ref} (tombolActivate=${!!actBtn})`);
    if (st.active && !actBtn) { log(tag, `Inference AKTIF (${st.ref})`); return { ok: true }; }
    if (!actBtn) { log(tag, "Activate & konten billing belum ada — ganti proxy"); return { ok: false, reason: "billing-not-loaded" }; }

    const clicked = await clickInferenceActivate(p);
    if (!clicked) {
      log(tag, "klik Activate gagal — refresh");
      await p.reload({ waitUntil: "domcontentloaded", timeout: 60000 }).catch(() => {});
      await sleep(4000);
      continue;
    }
    log(tag, "klik Activate Inference — tunggu popup...");

    // tunggu popup (sampai muncul)
    let ready = await visible(p, ['input[placeholder="Name on card"]', 'text=/Activate pay-as-you-go for Inference/i'], 30000);
    for (let w = 0; w < 4 && !ready; w++) {
      if ((await inferStatus(p)).active) return { ok: true };
      log(tag, `popup belum muncul (wait ${w + 1}) — refresh + ulang`);
      await ensureBilling(p, acc, tag, true);
      if ((await inferStatus(p)).active) return { ok: true };
      if (!(await clickInferenceActivate(p))) break;
      ready = await visible(p, ['input[placeholder="Name on card"]', 'text=/Activate pay-as-you-go for Inference/i'], 25000);
    }
    if (!ready) { log(tag, "popup Activate gagal muncul setelah retry"); continue; }

    await appendDump(acc.username, "billing-popup", p).catch(() => {});
    await sleep(1200);
    await fillBillingForm(p, acc, tag);
    await appendDump(acc.username, "billing-popup-filled", p).catch(() => {});
    await sleep(700);

    // klik Activate di modal (sekali)
    await p.getByRole("button", { name: /^activate$/i }).last().click({ timeout: 8000 }).catch(() => clickText(p, /^activate$/i, { timeout: 4000 }).catch(() => {}));

    // TUNGGU popup "Inference pay-as-you-go activated" (processing bisa lama)
    let okPopup = await visible(p, ['text=/inference pay-as-you-go activated/i', 'text=/pay-as-you-go activated/i'], 120000);
    await appendDump(acc.username, "billing-after-activate", p).catch(() => {});

    let b = await bodyText(p);
    if (/(card was declined|declined|not be verified|unsupported card|card was not)/i.test(b) && !okPopup) {
      const line = (b.match(/[^\n]*(declined|unsupported card|not be verified)[^\n]*/i) || [])[0];
      log(tag, `CARD DECLINED: ${line}`);
      return { ok: false, reason: "declined" };
    }

    // klik OK lalu TUNGGU auto-refresh + halaman terload betul
    if (okPopup) log(tag, "popup 'Inference pay-as-you-go activated' muncul — klik OK");
    await clickText(p, /^(ok|done|got it|close)$/i, { timeout: 10000 }).catch(() => {});
    await sleep(3000);
    await p.waitForLoadState("networkidle", { timeout: 40000 }).catch(() => {});
    await sleep(6000);
    await dismissCookies(p);

    // VALIDASI WAJIB: "Activate" hilang & jadi "No billable usage / View usage"
    st = await inferStatus(p);
    if (!st.active) {
      log(tag, `validasi: belum (${st.ref}) — reload halaman billing`);
      await p.reload({ waitUntil: "domcontentloaded", timeout: 60000 }).catch(() => {});
      await p.waitForLoadState("networkidle", { timeout: 30000 }).catch(() => {});
      await sleep(5000);
      await dismissCookies(p);
      st = await inferStatus(p);
    }
    if (st.active) { log(tag, `VALIDASI OK — Inference jadi No billable usage/View usage tanpa Activate (${st.ref})`); return { ok: true }; }
    log(tag, `validasi gagal (ref ${st.ref}) — ulangi`);
  }
  return { ok: false, reason: "max-attempt" };
}

// ======================= ACCOUNT RUNNER =======================
async function runAccount(acc, nextProxy, tag) {
  const maxAttempts = Number(val("--max-attempts", "3")) || 3;
  let lastErr = null;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    const proxy = nextProxy();
    let browser = null;
    let context = null;
    try {
      log(tag, `attempt ${attempt}/${maxAttempts} (proxy: ${proxy ? proxy.label : "direct"}) — launch Camoufox...`);
      browser = await launchBrowser(proxy);
      context = await browser.newContext();
      context.setDefaultTimeout(45000);
      context.on("page", (pg) => {
        pg.on("console", (m) => { if (m.type() === "error") log(tag, `console.error: ${String(m.text()).slice(0, 160)}`); });
        pg.on("pageerror", (e) => log(tag, `pageerror: ${String(e?.message || e).slice(0, 160)}`));
      });

      // CEK IP: exit IP lewat proxy harus UNIK (belum pernah dipakai)
      try {
        const ipPage = await context.newPage();
        const ip = await getExitIP(ipPage);
        await ipPage.close().catch(() => {});
        if (ip) {
          if (loadIpUsed().has(ip)) {
            log(tag, `IP exit ${ip} DUPLIKAT — ganti proxy`);
            if (proxy) markProxyUsed(proxy.raw);
            continue;
          }
          markIpUsed(ip);
          log(tag, `IP exit proxy: ${ip} (unik ✔)`);
        } else log(tag, "IP exit nggak kebaca (lanjut)");
      } catch {}

      let page = await stepSignup(context, tag);
      page = await stepGithubLogin(page, acc, tag);
      if (OPTS.probe) {
        const d = await dumpFail(acc.username, "probe", page, { url: page.url() });
        log(tag, `PROBE stop di GitHub login. dump: ${d}`);
        return { status: "probe", probeDump: d };
      }
      page = await stepGithubAuthorize(context, tag);
      page = await stepWandbSignup(context, page, acc, tag);
      const { apiKey, activated } = await stepBillingAndKey(context, page, acc, tag);
      if (!activated) throw taggedError("ACTIVATION_FAIL", "Inference belum aktif setelah validasi");

      saveKey({ username: acc.username, key: apiKey, createdAt: new Date().toISOString(), proxy: proxy ? proxy.raw : "direct" });
      markUsed(acc.username, "OK", `key=${short(apiKey, 6)} proxy=${proxy ? proxy.label : "direct"}`);
      if (proxy) markProxyUsed(proxy.raw);
      return { status: "ok", apiKey, activated };
    } catch (e) {
      lastErr = e;
      const code = e.code || "ERROR";
      const retryable = ["ACTIVATION_FAIL", "STOP"].includes(code) || /declin|proxy|timeout|net::|ECONN|navigation/i.test(e.message || "");
      const isStop = code === "STOP";
      const d = await dumpFail(acc.username, `${code}-a${attempt}`, context ? context.pages().slice(-1)[0] : null, { msg: e.message, code });
      log(tag, `attempt ${attempt} GAGAL [${code}]: ${e.message}${retryable && !isStop && attempt < maxAttempts ? " — ganti proxy, ulang akun ini" : ""} — dump ${d}`);
      if (proxy) markProxyUsed(proxy.raw); // proxy terpakai → jangan dipakai lagi (Jack)
      if (isStop) return { status: "stop", code, message: e.message };
      if (!retryable || attempt >= maxAttempts) {
        markUsed(acc.username, code, e.message);
        return { status: "fail", code, message: e.message };
      }
    } finally {
      if (context && !OPTS.keepOpen) await context.close().catch(() => {});
      if (browser && !OPTS.keepOpen) await browser.close().catch(() => {});
    }
    await sleep(2000);
  }
  markUsed(acc.username, lastErr?.code || "ERROR", lastErr?.message || "");
  return { status: "fail", code: lastErr?.code || "ERROR", message: lastErr?.message || "" };
}

// ======================= MAIN =======================
async function main() {
  const allAccounts = parseAccounts(OPTS.accounts);
  const card = parseCard(OPTS.cardFile);
  let proxies = OPTS.noProxy ? [] : loadProxies(OPTS.proxyFile);

  const used = loadUsed(OPTS.usedOut);
  let queue = allAccounts.filter((a) => OPTS.only ? a.username.toLowerCase() === OPTS.only.toLowerCase() : true);
  if (!OPTS.reuseUsed) queue = queue.filter((a) => !used.has(a.username.toLowerCase()));
  if (OPTS.maxAccounts > 0) queue = queue.slice(0, OPTS.maxAccounts);

  log("init", `akun: ${allAccounts.length} total, ${queue.length} di-queue | proxy: ${proxies.length} | card: ****${card.number.slice(-4)} exp ${card.exp}`);
  if (!queue.length) { log("init", "nggak ada akun buat diproses (semua used? pakai --reuse-used)."); return; }
  if (!proxies.length && !OPTS.noProxy) log("init", "WARNING: proxy.txt kosong — jalan direct");

  // proxy pointer (rotate, reset kalau habis)
  let proxyUsed = loadProxyUsed(OPTS.proxyUsed);
  let available = proxies.filter((p) => !proxyUsed.has(p.raw));
  if (!available.length && proxies.length) {
    log("proxy", "semua proxy udah dipakai — RESET pointer ke awal");
    fs.writeFileSync(OPTS.proxyUsed, "# reset " + new Date().toISOString() + "\r\n");
    proxyUsed = new Set();
    available = [...proxies];
  }

  const results = [];
  const started = Date.now();

  // pointer proxy: ambil berikutnya yang belum dipakai; reset ke awal kalau habis
  let pCursor = 0;
  const nextProxy = () => {
    if (!proxies.length || OPTS.noProxy) return null;
    if (pCursor >= available.length) {
      log("proxy", "semua proxy habis — RESET pointer ke awal");
      fs.writeFileSync(OPTS.proxyUsed, "# reset " + new Date().toISOString() + "\r\n");
      proxyUsed = new Set();
      available = [...proxies];
      pCursor = 0;
    }
    return available[pCursor++];
  };

  for (const acc of queue) {
    const tag = acc.username;
    acc.card = card;
    acc.names = genNames(acc, used);
    log(tag, `=== MULAI ===`);
    const r = await runAccount(acc, nextProxy, tag);
    results.push({ username: acc.username, ...r });
    await sleep(2000);
  }

  const okc = results.filter((r) => r.status === "ok").length;
  const fails = results.filter((r) => r.status === "fail");
  console.log("\n================ SUMMARY ================");
  for (const r of results) {
    console.log(`  ${r.status === "ok" ? "OK  " : r.status === "probe" ? "PROBE" : "FAIL"} ${r.username}${r.apiKey ? " key=" + short(r.apiKey, 6) : r.code ? " [" + r.code + "]" : ""}`);
  }
  console.log(`\n${okc} OK | ${fails.length} fail | ${((Date.now() - started) / 1000).toFixed(0)}s`);
  if (okc) console.log(`API keys -> ${OPTS.apiOut}`);
}

main().catch((e) => { console.error("FATAL:", e); process.exit(1); });
