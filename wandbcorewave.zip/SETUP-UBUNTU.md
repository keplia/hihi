# SETUP UBUNTU (VPS) — CoreWeave × W&B Farm (Camoufox)

Script **bisa run di Ubuntu** (Camoufox = Firefox-based, support Linux). Cocok kalau sinyal lokal lemot → pindah ke VPS.

## 1. Install dependency sistem
```bash
sudo apt update
sudo apt install -y curl xvfb build-essential python3 ca-certificates

# Node 20 LTS
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
node -v   # harus v20.x
```

## 2. Copy tool ke VPS
Copy folder (KECUALI `node_modules`, `dumps`, `logs`):
- `coreweave-bot.mjs`, `lib/`, `package.json`
- `gt.txt` (akun), `proxy.txt` (proxy), `cvc.txt` (kartu)
- (opsional) `probe.mjs`, `test-proxy.mjs`

Contoh dari lokal (ganti user@ip):
```bash
scp -r coreweave-bot.mjs lib package.json gt.txt proxy.txt cvc.txt ubuntu@IP_VPS:/home/ubuntu/wandbcorewave/
```

## 3. Install node deps + Camoufox browser
```bash
cd /home/ubuntu/wandbcorewave
npm install --no-audit --no-fund
npx camoufox-js fetch          # download Firefox Camoufox (~130MB) ke ~/.cache/camoufox
```
> Kalau `better-sqlite3` gagal build: `sudo apt install -y python3 make g++ && npm rebuild better-sqlite3`

## 4. Jalankan
```bash
# VPS tanpa display (auto pakai Xvfb virtual display):
node coreweave-bot.mjs --headless virtual --max-attempts 3

# atau headless murni:
node coreweave-bot.mjs --headless --max-attempts 3

# VPS pakai desktop / X server (keliatan browser):
node coreweave-bot.mjs --max-attempts 3
```

Log ke `logs/run-<tanggal>.log`, dump error ke `dumps/`.

## 5. Jalanin 24/7 (systemd)
`/etc/systemd/system/wandbfarm.service`:
```ini
[Unit]
Description=CoreWeave W&B Farm
After=network-online.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/home/ubuntu/wandbcorewave
ExecStart=/usr/bin/node coreweave-bot.mjs --headless virtual --max-attempts 3
Restart=on-failure
RestartSec=10
StandardOutput=append:/home/ubuntu/wandbcorewave/logs/service.log
StandardError=append:/home/ubuntu/wandbcorewave/logs/service.err

[Install]
WantedBy=multi-user.target
```
```bash
sudo systemctl daemon-reload
sudo systemctl enable --now wandbfarm
journalctl -u wandbfarm -f
```

## 6. Output
- `api.txt` — hasil API key (`username | api_key | created_at | proxy`)
- `used.txt` — status akun (biar nggak diulang)
- `proxy-used.txt` — pointer proxy terpakai (reset otomatis kalau habis)
- `ip-used.txt` — IP terpakai (jaga IP unik)
- `names-used.txt` — registry nama/address unik

## Catatan penting (hasil testing)
- **Proxy WAJIB tipe HTTP** (bukan SOCKS5). Camoufox/Firefox + SOCKS5-with-auth = `NS_ERROR_UNKNOWN_PROXY_HOST`.
  Format `proxy.txt`: `host:port:user:pass`
- **`geoip` dimatikan** (Camoufox geoip fetch suka hang). Timezone ikut sistem — pastikan VPS TZ Asia/Jakarta:
  `sudo timedatectl set-timezone Asia/Jakarta`
- Stripe diisi **pelan + urutan random** (biar lolos anti-bot) → sudah otomatis.
- Tiap akun = **profile/fingerprint/device-id + proxy fresh** (Camoufox random per launch, `enable_cache:false`).
