import { Camoufox } from "camoufox-js";

const t0 = Date.now();
try {
  const browser = await Camoufox({
    headless: true,
    os: "windows",
    humanize: true,
    locale: "en-US",
    geoip: false,
    block_webrtc: true,
    exclude_addons: ["UBO"],
    disable_coop: true,
  });
  console.log("launched in", ((Date.now() - t0) / 1000).toFixed(1), "s");
  const page = await browser.newPage();
  await page.goto("https://example.com", { waitUntil: "domcontentloaded", timeout: 45000 });
  console.log("TITLE:", await page.title());
  console.log("UA:", await page.evaluate(() => navigator.userAgent));
  console.log("webdriver:", await page.evaluate(() => navigator.webdriver));
  console.log("platform:", await page.evaluate(() => navigator.platform));
  await browser.close();
  console.log("OK total", ((Date.now() - t0) / 1000).toFixed(1), "s");
} catch (e) {
  console.error("ERR:", e.message);
}
