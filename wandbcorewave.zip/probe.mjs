#!/usr/bin/env node
// PROBE — baca DOM asli id.coreweave.com (sign-in / sign-up) biar selector akurat.
// Nggak consume kredensial. Cuma navigasi public + dump.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { openBrowser, newContext } from "./lib/browser.mjs";
import { loadProxies, toPlaywrightProxy } from "./lib/proxy.mjs";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DUMP = path.join(__dirname, "dumps");
fs.mkdirSync(DUMP, { recursive: true });

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const stamp = () => new Date().toISOString().replace(/[:.]/g, "-");

async function snapshot(page, name) {
  const base = path.join(DUMP, `probe-${name}-${stamp()}`);
  try {
    await page.screenshot({ path: `${base}.png`, fullPage: true }).catch(() => {});
    const html = await page.content().catch(() => "");
    await fs.promises.writeFile(`${base}.html`, html);
    const txt = await page.locator("body").innerText().catch(() => "");
    await fs.promises.writeFile(`${base}.txt`, txt);
    // Semua elemen interaktif + teksnya
    const els = await page
      .evaluate(() => {
        const out = [];
        const nodes = document.querySelectorAll(
          'button, a, input, select, textarea, [role="button"], [role="link"], [role="tab"], label, [class*="Button"], [class*="button"]'
        );
        for (const el of nodes) {
          const r = el.getBoundingClientRect();
          const vis = r.width > 0 && r.height > 0;
          const t = (el.innerText || el.value || el.getAttribute("aria-label") || el.getAttribute("placeholder") || "").replace(/\s+/g, " ").trim();
          out.push({
            tag: el.tagName,
            type: el.getAttribute("type") || "",
            name: el.getAttribute("name") || "",
            id: el.id || "",
            testid: el.getAttribute("data-testid") || "",
            href: el.getAttribute("href") || "",
            ph: el.getAttribute("placeholder") || "",
            vis,
            text: t.slice(0, 90),
          });
        }
        return out.filter((e) => e.vis || e.text);
      })
      .catch(() => []);
    await fs.promises.writeFile(`${base}.els.json`, JSON.stringify({ url: page.url(), els }, null, 2));
    console.log(`\n### ${name} — URL: ${page.url()}`);
    console.log("body text:\n" + (txt || "").slice(0, 2500));
    console.log("\ninteractive:");
    for (const e of els.slice(0, 60)) {
      if (!e.text && !e.href && !e.ph && !e.name) continue;
      console.log(`  <${e.tag}${e.type ? " type=" + e.type : ""}${e.name ? " name=" + e.name : ""}${e.id ? " id=" + e.id : ""}${e.testid ? " testid=" + e.testid : ""}${e.href ? " href=" + e.href : ""}${e.ph ? " ph=" + e.ph : ""}> ${e.text}`);
    }
    return base;
  } catch (e) {
    console.log(`snapshot ${name} err: ${e.message}`);
    return null;
  }
}

async function clickFirst(page, texts, label) {
  const res = await page
    .evaluate((texts) => {
      const norm = (s) => String(s || "").replace(/\s+/g, " ").trim().toLowerCase();
      const nodes = Array.from(document.querySelectorAll('button, a, [role="button"], input[type="submit"], [data-testid]'));
      for (const t of texts) {
        const hit = nodes.find((el) => {
          const txt = norm(el.innerText || el.value || el.getAttribute("aria-label") || "");
          return txt === t || txt.includes(t);
        });
        if (hit) {
          hit.scrollIntoView({ block: "center" });
          hit.click();
          return { ok: true, text: norm(hit.innerText || hit.value), matched: t };
        }
      }
      return { ok: false };
    }, texts.map((t) => t.toLowerCase()))
    .catch((e) => ({ ok: false, err: e.message }));
  console.log(`click[${label}] -> ${JSON.stringify(res)}`);
  return res.ok;
}

async function main() {
  const proxies = loadProxies(path.join(__dirname, "proxy.txt"));
  const useProxy = process.argv.includes("--proxy") && proxies.length;
  const proxy = useProxy ? toPlaywrightProxy(proxies[0]) : null;
  console.log(`proxies loaded: ${proxies.length}${useProxy ? " (pakai #1)" : " (direct)"}`);

  const browser = await openBrowser({ headless: !process.argv.includes("--headed") });
  const context = await newContext(browser, { proxy });
  const page = await context.newPage();

  try {
    await page.goto("https://id.coreweave.com/login?next=%2F", { waitUntil: "domcontentloaded", timeout: 60000 });
    await sleep(4000);
    await snapshot(page, "01-login");

    // Klik Sign up
    await clickFirst(page, ["sign up", "signup", "create account", "register", "get started"], "signup");
    await sleep(4000);
    await snapshot(page, "02-signup");

    // Klik Continue with Github
    await clickFirst(page, ["continue with github", "sign in with github", "github", "continue with git hub"], "github");
    await sleep(5000);
    await snapshot(page, "03-github");

    await sleep(2000);
  } catch (e) {
    console.log("ERR:", e.message);
  } finally {
    if (!process.argv.includes("--keep")) await browser.close();
  }
}

main();
