import { Camoufox } from "camoufox-js";

const user = "zdy31248719-region-ID-sid-CMRPymeT-t-5";
const pass = "4zzrtasq";

async function test(scheme, geoip) {
  const proxy = { server: `${scheme}://sg.cliproxy.io:3010`, username: user, password: pass };
  const t0 = Date.now();
  try {
    const b = await Camoufox({ headless: true, os: "windows", humanize: true, locale: "en-US", geoip, block_webrtc: true, exclude_addons: ["UBO"], disable_coop: true, i_know_what_im_doing: true, enable_cache: false, proxy });
    const p = await b.newPage();
    await p.goto("https://ipinfo.io/json", { waitUntil: "domcontentloaded", timeout: 35000 });
    const t = await p.locator("body").innerText();
    console.log(`OK ${scheme} geoip=${geoip} (${((Date.now() - t0) / 1000).toFixed(1)}s): ${t.replace(/\s+/g, " ").slice(0, 140)}`);
    await b.close();
  } catch (e) {
    console.log(`ERR ${scheme} geoip=${geoip}: ${e.message}`);
  }
}

await test("socks5", false);
await test("socks5", true);
await test("http", false);
